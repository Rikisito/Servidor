<?php $val = Validacion::getInstance(); ?>
<html>
<head>
    <meta charset="UTF-8">
    <title>GESTION DE LA BASE DE DATOS DE USUARIOS</title>
    <style>
        form {
            padding-top: 50px;
        }

        .has-error {
            background: red;
            color: white;
            padding: 0.2em;
        }

        .has-warning {
            background: blue;
            color: white;
            padding: 0.2em;
        }
    </style>
</head>
<body>
<div>
    <form action="index.php?pagina=busqueda" method="post">
        <h1>CONSULTA DE NOTAS</h1>
        {{errores}}
        <div>
            <label class=" {{class-asignaturas}}" for="asignaturas">Asignatura: </label>
            <input type="text" id="asignaturas" name="asignaturas"
                   value='<?php echo $val->restoreValue('asignaturas'); ?>'>
            <span>{{war-asignaturas}}</span>

            <label for="curso">Curso </label>
            <select name="curso" id="curso">
                <option value="todos">Todos</option>
                <option value="ESO1">ESO 1</option>
                <option value="ESO2">ESO 2</option>
            </select>
        </div>
        <div>
            <label for="registros">Mostrar nº registros </label>
            <input type="checkbox" name="registros" id="registros">
        </div>
        <div class="">
            Mostar <label for="aprobados">Aprobados</label><input type="radio" name="nota" id="aprobados"
                                                                  value="aprobados">
            <label for="suspensos">Suspensos</label><input type="radio" name="nota" id="suspensos" value="suspensos">
            <label for="todos">Todos</label><input type="radio" name="nota" id="todos" checked value="todos">
        </div>
        <br>
        <div>
            <button type="submit" name="busqueda">Consultar </i></button>
        </div>
    </form>
</div>

</body>
</html>