<?php

class ListadoParser {
	public static function loadContent($vista) {
		$vista = self::_pasoSiguiente($vista);
		return $vista;
	}

	private static function _pasoSiguiente($vista) {
		foreach (getTagsVista($vista) as $tag) {
// sustituimos en el formulario los tags por el contenido de los elementos del formulario
			$str = '';
			switch ($tag) {
				case 'listado':
					$datos = $_SESSION['datos'];
					if (count($datos) > 0) {
						$str = "<table border='1'><tr>";
// Recorremos los campos de la primera fila de datos devueltos (en este caso una única fila)
// para averiguar los nombres de los campos
						foreach ($datos[0] as $field => $value) {
							$str .= "<th>$field</th>";
						}
						$str .= "</tr>";
// Recorremos las filas de datos devueltos (en este caso única fila luego no haría falta un bucle)
						foreach ($datos as $producto) {
							$str .= "<tr>";
							foreach ($producto as $value)
								$str .= "<td><strong>" . $value . "</strong></td>";
							$str .= "</tr>";
						}
						if (isset($_SESSION["busqueda"]["registros"])){
							$str .= "Numero de registros encontrados: ".count($datos);
						}

					} else
						$str = '<p><b>No se han encontrado resultados...</b></p>';
					break;
			}
			$vista = str_replace('{{' . $tag . '}}', $str, $vista);
		}
		return $vista;
	}
}