<?php

class Nota
{
    public static function buscarAsignaturaNormal($asignatura)
    {
        $database = Conexion::getInstance();
        $database->openConnection(MYSQL_CONFIG);

        $where=array();
        $operador='';

        $where[] = "asignatura = '$asignatura'";
        if ($_SESSION['busqueda']['curso']<>'todos') {
            $curso = $_SESSION['busqueda']['curso'];
            $where[] = "curso = '$curso'";
        }
        if ($_SESSION['busqueda']['nota']<>'todos') {
            $operador = ($_SESSION['busqueda']['nota']=='suspensos')?'<': '>=';
            $where[] = "nota $operador 5";
        }
        $where = implode(' AND ',$where);
        $sql = "select * from notas_alumnos ";
        $sql.=' WHERE '.$where;


        $pdo=$database->getPdo();
        $query = $pdo->query($sql);
        $datos = $query ? $query->fetchAll(PDO::FETCH_ASSOC) : false;
        $database->closeConnection();
        return $datos;
    }

    public static function buscarAsignaturaPreparada($asignatura)
    {
        $database = Conexion::getInstance();
        $database->openConnection(MYSQL_CONFIG);

        $where[] = "asignatura = :asignatura";
        $param[":asignatura"] = $asignatura;
        if ($_SESSION['busqueda']['curso'] <> 'todos') {
            $curso = $_SESSION['busqueda']['curso'];
            $where[] = "curso = :curso";
            $param[":curso"] = $curso;
        }
        if ($_SESSION['busqueda']['nota'] <> 'todos') {
            $operador = ($_SESSION['busqueda']['nota'] == 'suspensos') ? '<' : '>=';
            $where[] = "nota $operador 5";
        }
        $where = implode(' AND ', $where);
        $sql = "select * from notas_alumnos ";
        $sql .= ' WHERE ' . $where;

        $pdo = $database->getPdo();
        $query = $pdo->prepare($sql);
        $query->execute($param);
        $datos = $query ? $query->fetchAll(PDO::FETCH_ASSOC) : false;
        $database->closeConnection();
        return $datos;
    }


    public static function buscarAsignaturaMedoo($asignatura)
    {

        $where['AND']["asignatura"] = $asignatura;
        if ($_SESSION['busqueda']['curso'] != 'todos') {
            $curso = $_SESSION['busqueda']['curso'];
            $where['AND']["curso"] = $curso;
        }

        if ($_SESSION['busqueda']['nota'] != 'todos') {
            $operador = ($_SESSION['busqueda']['nota'] == 'suspensos') ? '<' : '>=';
            $indice = "nota[$operador]";
            $where['AND']["$indice"] = 5;
        }
        $database = medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $datos = $database->select('notas_alumnos', '*', $where);
        return $datos;

    }
}