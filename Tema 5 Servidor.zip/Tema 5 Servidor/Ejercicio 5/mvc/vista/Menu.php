<html>
    <head>
        <meta charset="UTF-8">
        <title>Listado de usuarios</title>
        <style>
            dl {
                padding-top: 50px;
            }
        </style>
    </head>
    <body>
        <h1>Menu</h1>
        {{register}}
        {{msg}}
        <br>
    </body>
</html>
