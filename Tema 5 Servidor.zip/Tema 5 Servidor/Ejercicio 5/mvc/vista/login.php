<?php $val = Validacion::getInstance();?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>GESTION DE LA BASE DE DATOS DE USUARIOS</title>
		<style>
			form {
				padding-top: 50px;
			}
			.has-error { background: red; color: white; padding: 0.2em; }
			.has-warning { background: blue; color: white; padding: 0.2em; }
		</style>
	</head>
	<body>
		<div>
			<form action="index.php?pagina=login" method="post">
				<h1>GESTION DE LA BASE DE DATOS DE USUARIOS. añadir</h1>
				{{errores}}
				<div>
					<label class=" {{class-usuario}}" for="usuario">usuario</label>
					<input type="text" id="usuario" name="usuario"
						   value='<?php echo $val->restoreValue('Clientes'); ?>' >
					<span>{{war-usuario}}</span>
				</div>
				<br>
				<div>
					<label class=" {{class-password}}" for="password">password</label>
					<input type="text" id="password" name="password"
						   value='<?php echo $val->restoreValue('password'); ?>' >
					<span>{{war-password}}</span>
				</div>
				<br>
				<div>
					<button type="submit" name="login">Login</i></button>
				</div>
			</form>
		</div>
	</body>
</html>