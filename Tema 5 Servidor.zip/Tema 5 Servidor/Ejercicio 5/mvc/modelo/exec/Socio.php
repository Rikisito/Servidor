<?php

class Socio {
	public static function duplicateDNI($dni) {
		$database = Medoo::getInstance();
		$database->openConnection(MYSQL_CONFIG);
		$datos = ($database->count('socios', ['dni' => $dni]) > 0) ? true : false;
		$database->closeConnection();
		return $datos;
	}

	public static function  insertDB($nombre,$dni,$cuota)  {
		$database = Conexion::getInstance();
		$database->openConnection(MYSQL_CONFIG);
		$sql = "insert into socios (Nombre,dni,cuota) values (:nombre,:dni,:cuota)";
		$pdo=$database->getPdo();
		$query = $pdo->prepare($sql);
		$param= array(":nombre" => $nombre,":dni" => $dni,":cuota" => $cuota);
		$query->execute($param);
		$datos = $query->rowCount() > 0 ? true : false;
		$database->closeConnection();
		return $datos;
	}
}

?>
