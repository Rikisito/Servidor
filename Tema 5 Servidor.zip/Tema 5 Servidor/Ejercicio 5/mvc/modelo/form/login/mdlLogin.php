<?php
/**
 * <!--
 *   Copyright (C) Daw2 2018
 *
 *
 *
 *   This program is free software: you can redistribute it and/or modify
 *
 *   it under the terms of the GNU General Public License as published by
 *
 *   the Free Software Foundation, either version 3 of the License, or
 *
 *   (at your option) any later version.
 *
 *
 *
 *   This program is distributed in the hope that it will be useful,
 *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *
 *   GNU General Public License for more details.
 *
 *
 *
 *   You should have received a copy of the GNU General Public License
 *
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>
 *   -->
 */

class mdlLogin extends Singleton
{
    const PAGE = 'login';

    public function onGestionPagina()
    {
        if (getGet('pagina') != self::PAGE) return;
// Validamos
        $val = Validacion::getInstance();
// Validamos los elementos que hay en $_POST
        $toValidate = ($_POST);
        $rules = array(
            'Clientes' => 'required|alphanum_simple',
            'password' => 'required'
        );
        $val->addRules($rules);
        $val->run($toValidate);
        if (!is_null(getPost(self::PAGE))) {
            if ($val->isValid()) {
// Guardamos los datos en session
                $_SESSION[self::PAGE] = $val->getOks();
                $datos = Login::searchUsuarioDB(getPost('Clientes'), getPost('password'));
                if ($datos) {
                    $_SESSION['info'] = 'logged';
                } else
                    $_SESSION['info'] = 'nologged';
// Cambiamos el paso
                redirectTo('index.php?pagina=menu');
            }
        }
    }

    public function onCargarVista($path)
    {
        if (getGet('pagina') != self::PAGE) return;
        ob_start();
        include $path;
        $vista = ob_get_contents();
        ob_end_clean();
        echo LoginParser::loadContent($vista);
    }
}