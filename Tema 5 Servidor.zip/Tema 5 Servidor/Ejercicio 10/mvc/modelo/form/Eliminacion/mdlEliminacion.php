<?php

class mdlEliminacion extends Singleton
{
    const PAGE = 'eliminacion';

    public function onGestionPagina()
    {
        if (getGet('pagina') != self::PAGE || !(Session::get('info') == 'logged')) return;
        if (getGet('id')) {
            $_SESSION['eliminacion'] = getGet('id');
            $datos = Usuario::removeDB(getGet('id'));
            if ($datos)
                $_SESSION['elim'] = true;
            else
                $_SESSION['elim'] = false;

            redirectTo('index.php?pagina=mensaje');
        }
    }

    public function onCargarVista($path)
    {
        if (getGet('pagina') != self::PAGE || !(Session::get('info') == 'logged')) return;
        ob_start();
        include $path;
        $vista = ob_get_contents();
        ob_end_clean();
        echo EliminacionParser::loadContent($vista);
    }
}

?>
