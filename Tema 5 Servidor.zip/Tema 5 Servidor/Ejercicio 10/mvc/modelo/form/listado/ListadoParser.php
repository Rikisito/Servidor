<?php
class ListadoParser {
    public static function loadContent($vista) {
        $vista = self::_pasoSiguiente($vista);
        return $vista;
    }
    private static function _pasoSiguiente($vista) {
        foreach (getTagsVista($vista) as $tag) {
// sustituimos en el formulario los tags por el contenido de los elementos del formulario
            $str = '';
            switch ($tag) {
                case 'listado':
                    $datos=$_SESSION['datos'];
                    if (count($datos) > 0) {
                        foreach ($datos as $cliente) {
                            $str .= $cliente['id']." ". $cliente['nombre'] ." ".$cliente['apellidos'];
                            $str .= " <a href='?pagina=busqueda&id=".$cliente['id']."'>Mostrar</a>
                                <a href='?pagina=edicion&id=".$cliente['id']."'>Modificar</a>
                                <a href='?pagina=eliminacion&id=".$cliente['id']."'>Eliminar</a><br>";
                        }
                    } else
                        $str = '<p> <b>No se han encontrado resultados...</b></p>';
                    break;
            }
            $vista = str_replace('{{' . $tag . '}}', $str, $vista);
        }
        return $vista;
    }
}