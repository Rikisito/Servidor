<?php
class mdlListado extends Singleton {
	const PAGE = 'listado';
	public function onGestionPagina() {
		if (getGet('pagina') != self::PAGE || !(Session::get('info') == 'logged')) return;
// Si no ha pasado por el paso Busqueda (si se modifica el valor de la variable en la url), se vuelve a visualizar la página inicial
		if (!isset($_SESSION['busqueda'])) {
			$_SESSION['datos'] = Usuario::searchAllDB();
		}
	}
	public function onCargarVista($path) {
		if (getGet('pagina') != self::PAGE || !(Session::get('info') == 'logged')) return;
		ob_start();
		include $path;
		$vista = ob_get_contents();
		ob_end_clean();
		echo ListadoParser::loadContent($vista);
	}
}