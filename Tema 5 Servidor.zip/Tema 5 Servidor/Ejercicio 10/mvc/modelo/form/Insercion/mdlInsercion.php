<?php

class mdlInsercion extends Singleton {
	const PAGE = 'insercion';

	public function onGestionPagina() {
		if (getGet('pagina') != self::PAGE || !(Session::get('info') == 'logged')) return;
// Validamos
		$val = Validacion::getInstance();
// Validamos los elementos que hay en $_POST
		$toValidate = ($_POST);
		$rules = array(
            'nombre' => 'required|alpha_space',
            'apellidos' => 'required|alpha_space',
            'dni' => 'duplicate|dni',
            'email' => 'required|email'
		);

        if (Usuario::duplicateDNI(getPost('dni'))){
            $val->setExists(true);
        }

		$val->addRules($rules);
		$val->run($toValidate);
		if (!is_null(getPost(self::PAGE))) {
			if ($val->isValid()) {
// Guardamos los datos en session
				$_SESSION[self::PAGE] = $val->getOks();
				$data = $_SESSION[self::PAGE];
				$datos = Usuario::insertDB($data);
				if ($datos)
					$_SESSION['ins'] = true;
				else
					$_SESSION['ins'] = false;
				// Cambiamos el paso
				redirectTo('index.php?pagina=mensaje');

			}
		}
	}

	public function onCargarVista($path) {
		if (getGet('pagina') != self::PAGE || !(Session::get('info') == 'logged')) return;
		ob_start();
		include $path;
		$vista = ob_get_contents();
		ob_end_clean();
		echo InsercionParser::loadContent($vista);
	}
}