<?php

class mdlEdicion extends Singleton
{
    const PAGE = 'edicion';

    public function onGestionPagina()
    {
        if (getGet('pagina') != self::PAGE || !(Session::get('info') == 'logged')) return;
        if (is_null(getPost('edicion'))) {
            if (!getGet('id')) redirectTo('index.php');
            $_SESSION[self::PAGE]['id'] = getGet('id');
            $datos = Usuario::searchIdDB(getGet('id'));

            if (count($datos) > 0) {
                // Utilizamos la validación para rellenar los campos del formulario.
                $val = Validacion::getInstance();
                $toValidate = $datos[0];
                $rules = array(
                    'nombre' => 'required|alpha_space',
                    'apellidos' => 'required|alpha_space',
                    'dni' => 'required|duplicateDNI|dni',
                    'email' => 'required|email'
                );
                $val->addRules($rules);
                $val->run($toValidate);
            } else {
                redirectTo('index.php?pagina=mensaje');
            }
        } else {
            $val = Validacion::getInstance();
            $toValidate = $_POST;
            $rules = array(
                'nombre' => 'required|alpha_space',
                'apellidos' => 'required|alpha_space',
                'dni' => 'duplicate|dni',
                'email' => 'required|email'
            );

            if (Usuario::duplicateDNI(getPost('dni'),$_SESSION[self::PAGE]['id'])){
                $val->setExists(true);
            }


            $val->addRules($rules);
            $val->run($toValidate);
            if ($val->isValid()) {
                $_SESSION[self::PAGE] = array_merge($_SESSION[self::PAGE], $val->getOks());
                $data = $_SESSION['edicion'];
                $id = $_SESSION[self::PAGE]['id'];
                $datos = Usuario::modifyDB($data, $id);
                if ($datos)
                    $_SESSION['mod'] = true;
                else
                    $_SESSION['mod'] = false;
                redirectTo('index.php?pagina=mensaje');
            }


        }
    }

    public function onCargarVista($path)
    {
        if (getGet('pagina') != self::PAGE || !(Session::get('info') == 'logged')) return;
        ob_start();
        include $path;
        $vista = ob_get_contents();
        ob_end_clean();
        echo EdicionParser::loadContent($vista);
    }
}

?>
