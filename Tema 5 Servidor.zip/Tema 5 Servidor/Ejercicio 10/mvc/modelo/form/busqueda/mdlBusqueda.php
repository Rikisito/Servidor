<?php

class mdlBusqueda extends Singleton
{
    const PAGE = 'busqueda';

    public function onGestionPagina()
    {
        if (getGet('pagina') != self::PAGE || !(Session::get('info') == 'logged')) return;
        $_SESSION['busqueda'] = Usuario::searchIdDB(getGet('id'));

        redirectTo('index.php?pagina=mensaje');
    }

    public function onCargarVista($path)
    {
        if (getGet('pagina') != self::PAGE || !(Session::get('info') == 'logged')) return;
        ob_start();
        include $path;
        $vista = ob_get_contents();
        ob_end_clean();
        echo BusquedaParser::loadContent($vista);
    }
}