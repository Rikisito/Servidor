<?php

class mdlLogin extends Singleton
{
    const PAGE = 'login';

    public function onGestionPagina()
    {
        if (getGet('pagina') != self::PAGE) return;
// Validamos
        if (!isset($_SERVER['PHP_AUTH_USER'])) {
            header('WWW-Authenticate: Basic realm="Contenido restringido"');
            header("HTTP/1.0 401 Unauthorized");
// la dos líneas siguientes sólo se ejecutan cuando se pulsa el botón Cancelar ya que no se hace una nueva petición de la página
            echo "Usuario no introducido!";
            exit;
        } else {
            $usuario = $_SERVER['PHP_AUTH_USER'];
            $clave = $_SERVER['PHP_AUTH_PW'];
            $datos = Usuario::searchUsuarioDB($usuario, $clave);
            if ($datos) {
// Cambiamos el paso
                $_SESSION['info'] = 'logged';
                redirectTo('index.php?pagina=inicio');
            } else {
                header('WWW-Authenticate: Basic realm="Contenido restringido"');
                header("HTTP/1.0 401 Unauthorized");
// la dos líneas siguientes sólo se ejecutan cuando se pulsa el botón Cancelar ya que no se hace una nueva petición de la página
                echo "Usuario no introducido!";
                exit;
            }
        }
    }
}