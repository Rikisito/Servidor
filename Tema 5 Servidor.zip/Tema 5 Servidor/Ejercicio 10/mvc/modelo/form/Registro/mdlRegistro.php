<?php

class mdlRegistro extends Singleton {
	const PAGE = 'registro';

	public function onGestionPagina() {
		if (getGet('pagina') != self::PAGE || !(Session::get('info') == 'logged')) return;

		if (is_null(Session::get('info'))) redirectTo('index.php');

// Validamos
		$val = Validacion::getInstance();
// Validamos los elementos que hay en $_POST
		$toValidate = ($_POST);
		$rules = array(
			'usuario' => 'required|alpha_numer_space_515',
			'password' => 'required|alpha_numer_space_515',
			'nombre' => 'required|alpha_space',
			'apellidos' => 'required|space',
			'email' => 'required|email'
		);

		$usuario = getPost('usuario');
		// Verificamos si existe el usuario
		if (Usuario::duplicateUsuario($usuario))
			$val->setExists(true);

		$val->addRules($rules);
		$val->run($toValidate);
		if (!is_null(getPost(self::PAGE))) {
			if ($val->isValid()) {
// Guardamos los datos en session
				$_SESSION[self::PAGE] = $val->getOks();
				$data = $_SESSION['registro'];
				$datos = Usuario::insertDB($data);
				if ($datos) {
					$_SESSION['info'] = 'registed';
				} else
					$_SESSION['info'] = 'noRegisted';
// Cambiamos el paso
				redirectTo('index.php?pagina=menu');
			}
		}
	}

	public function onCargarVista($path) {
		if (getGet('pagina') != self::PAGE || !(Session::get('info') == 'logged')) return;
		ob_start();
		include $path;
		$vista = ob_get_contents();
		ob_end_clean();
		echo RegistroParser::loadContent($vista);
	}
}