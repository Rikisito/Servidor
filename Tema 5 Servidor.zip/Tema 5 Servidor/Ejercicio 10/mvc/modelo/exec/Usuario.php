<?php
class Usuario {
	public static function searchIdDB($id) {
		$database = Medoo::getInstance();
		$database->openConnection(MYSQL_CONFIG);
		$datos = $database->select("clientes","*",["id[=]"=>$id]);
		$database->closeConnection();
		return $datos;
	}
	public static function modifyDB($data,$id ) {
		$database = Medoo::getInstance();
		$database->openConnection(MYSQL_CONFIG);
		$datos = $database->update("clientes",$data,["id[=]"=>$id]);
		$database->closeConnection();
		return $datos;
	}

	public static function searchAllDB() {
		$database = Medoo::getInstance();
		$database->openConnection(MYSQL_CONFIG);
		$datos = $database->select("clientes","*");
		$database->closeConnection();
		return $datos;
	}
	public static function  insertDB($data)  {
		$database = Medoo::getInstance();
		$database->openConnection(MYSQL_CONFIG);
		$datos = $database->insert("clientes",$data);
		$database->closeConnection();
		return $datos;
	}

	public static function removeDB($id) {
		$database = Medoo::getInstance();
		$database->openConnection(MYSQL_CONFIG);
		$datos = $database->delete('clientes', ["id[=]" => $id]);
		$datos = $datos->rowCount() > 0 ? true : false; //medoo devuelve un objeto statement
		$database->closeConnection();
		return $datos;
	}

    public static function duplicateDNI($dni, $id = null) {
        $database = Medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $datos = ($database->count('clientes', ["AND" => ['dni' => $dni, 'id[!]'=>$id]]) > 0) ? true : false;
        $database->closeConnection();
        return $datos;
    }


	public static function  insertDBLogin($data)  {
		$database = Medoo::getInstance();
		$database->openConnection(MYSQL_CONFIG);
		$datos = $database->insert('login',$data);
		$database->closeConnection();
		return $datos;
	}

	public static function searchUsuarioDB($usuario, $clave) {
		$database = Medoo::getInstance();
		$database->openConnection(MYSQL_CONFIG);
		$datos = $database->count('login', [
				'AND' => [
					'usuario' => $usuario,
					'clave' => $clave
				]
			]) > 0;
		$database->closeConnection();
		return $datos;
	}

	public static function duplicateUsuario($usuario) {
		$database = Medoo::getInstance();
		$database->openConnection(MYSQL_CONFIG);
		$datos = ($database->count('login', ['usuario' => $usuario]) > 0) ? true : false;
		$database->closeConnection();
		return $datos;
	}


}