<?php $val = Validacion::getInstance(); ?>
<html>
<head>
	<meta charset="UTF-8">
	<title>GESTION DE LA BASE DE DATOS DE USUARIOS</title>


	<style>
		.has-error {
			background: red;
			color: white;
			padding: 0.2em;
		}

		.has-warning {
			background: blue;
			color: white;
			padding: 0.2em;
		}
		.has-duplicate{
			background: orange;
			color: white;
			padding: 0.2em;
		}
	</style>
<body>
	<div class="container">
		<form action="index.php?pagina=edicion" method="post">
			<h1>GESTION DE LA BASE DE DATOS DE USUARIOS. MODIFICAR</h1>
			{{errores}}
			<div>
				<label class=" {{class-nombre}}" for="nombre">Nombre</label>
				<input type="text" id="id" name="nombre"
					   Value='<?php echo $val->restoreValue('nombre'); ?>'>
				<span>{{war-nombre}}</span>
				<br>
				<label class=" {{class-apellidos}}" for="apellidos">apellidos</label>
				<input type="text" id="apellidos" name="apellidos"
					   Value='<?php echo $val->restoreValue('apellidos'); ?>'>
				<span>{{war-apellidos}}</span>

				<br>
				<label class=" {{class-dni}}" for="dni">dni</label>
				<input type="text" id="dni" name="dni"
					   Value='<?php echo $val->restoreValue('dni'); ?>'>
				<span>{{war-dni}}</span>

				<br>
				<label class=" {{class-email}}" for="email">email</label>
				<input type="text" id="email" name="email"
					   Value='<?php echo $val->restoreValue('email'); ?>'>
				<span>{{war-email}}</span>
			</div>
			<br>
			<div>
				<button type="submit" name="edicion">Enviar </i></button>
			</div>
		</form>
	</div>
	<br>
	<a href="index.php">Volver a Inicio</a>
</body>
</html>