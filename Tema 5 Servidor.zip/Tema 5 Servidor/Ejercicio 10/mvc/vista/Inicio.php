<html>
<head>
	<meta charset="UTF-8">
	<title>GESTION DE CLIENTES. INICIO</title>
	<link href="/gestionClientes/mvc/vista/comun.css" rel="stylesheet" type="text/css"/>
</head>
<body>
	<h1>GESTION DE CLIENTES. INICIO</h1>
	<br><br>
	<a href="?pagina=insercion">Añadir nuevo cliente</a>
	<br><br>
	<a href="?pagina=listado">Listado</a>
</body>
</html>