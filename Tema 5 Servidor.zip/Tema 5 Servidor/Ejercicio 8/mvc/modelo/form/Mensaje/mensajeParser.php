<?php

class MensajeParser
{
    public static function loadContent($vista)
    {
        $vista = self::_pasoSiguiente($vista);
        return $vista;
    }

    private static function _pasoSiguiente($vista)
    {
        foreach (getTagsVista($vista) as $tag) {
// sustituimos en el formulario los tags por el contenido de los elementos del formulario
            $str = '';
            switch ($tag) {
                case 'mensaje':
                    if (isset($_SESSION['mod']) && $_SESSION['mod']) {
                        $str = "Clientes Modificado";
                    }else if (isset($_SESSION['elim']) && $_SESSION['elim']) {
                        $str = "Clientes Eliminado";

                    } else if(isset($_SESSION['ins']) && $_SESSION['ins']){
                        $str = "Clientes Insertado";
                    }else if(isset($_SESSION['busqueda'])){
                        $infoClinete = $_SESSION['datos'][0];
                        $str = "<h3>Datos del Cliente</h3>";
                        foreach ($infoClinete as $index => $item) {
                            $str .= "<strong>$index:</strong> $item<br>";
                        }
                    }
                    break;
            }
            $vista = str_replace('{{' . $tag . '}}', $str, $vista);
        }
        return $vista;
    }
}

?>
