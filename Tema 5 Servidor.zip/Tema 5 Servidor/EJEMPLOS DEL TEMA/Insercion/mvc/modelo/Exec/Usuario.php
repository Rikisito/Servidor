<?php

class Usuario
{
    public static function insertNormalDB($nombre)
    {
        $database = Conexion::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $sql = "insert into usuarios (nombre) values('" . $nombre . "')";
        $pdo = $database->getPdo();
        $query = $pdo->exec($sql); // exec devuelve el número de registros insertados
        $datos = ($query) > 0 ? true : false;
        $database->closeConnection();
        return $datos;
    }


    public static function insertPreparadaDB($nombre)
    {
        $database = Conexion::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $sql = "insert into usuarios (nombre) values (:nombre)";
        $pdo = $database->getPdo();
        $query = $pdo->prepare($sql);
        $param = array(":nombre" => $nombre);
        $query->execute($param);
        $datos = $query->rowCount() > 0 ? true : false;
        $database->closeConnection();
        return $datos;
    }

    public static function insertMedooDB($data) {
        $database = medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $datos = $database->insert('usuarios', $data);
        $database->closeConnection();
        return $datos;
    }

}