<?php

class Usuario
{
    public static function removeNormalDB($id)
    {
        $database = Conexion::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $sql = "delete from usuarios where id = " . $id;
        $pdo = $database->getPdo();
        $datos = $pdo->exec($sql); // exec devuelve el número de registros eliminados
        $database->closeConnection();
        return $datos;
    }

    public static function removePreparadaDB($id)
    {
        $database = Conexion::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $sql = "delete from usuarios where id = :id";
        $pdo = $database->getPdo();
        $query = $pdo->prepare($sql);
        $param = array(":id" => $id);
        $query->execute($param); //execute devuelve true si no hay error (exista o no el registro
        $datos = $query->rowCount() > 0 ? true : false;
        $database->closeConnection();
        return $datos;
    }

    public static function removeMedooDB($id)
    {
        $database = medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $datos = $database->delete('usuarios', ["id[=]" => $id]);
        $datos = $datos->rowCount() > 0 ? true : false; //medoo devuelve un objeto statement
        $database->closeConnection();
        return $datos;
    }

}