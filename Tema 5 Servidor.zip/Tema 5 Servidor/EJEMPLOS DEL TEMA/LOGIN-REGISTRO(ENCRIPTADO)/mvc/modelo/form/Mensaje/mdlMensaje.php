<?php
/**
 * Created by PhpStorm.
 * User: Daw2
 * Date: 15/01/2018
 * Time: 9:43
 */
class mdlMensaje extends Singleton {
    const PAGE = 'mensaje';
    public function onGestionPagina() {
        if (getGet('pagina') != self::PAGE) return;
        // Si no ha pasado por el paso Busqueda (si se modifica el valor de la variable en la url), se vuelve a visualizar la página inicial
        if (!isset($_SESSION['insercion'])) redirectTo('index.php');
    }
    public function onCargarVista($path) {
        if (getGet('pagina') != self::PAGE) return;
        ob_start();
        include $path;
        $vista = ob_get_contents();
        ob_end_clean();
        echo MensajeParser::loadContent($vista);
    }
}
