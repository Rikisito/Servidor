<?php

class mdlLogin extends Singleton
{
    const PAGE = 'login';

    public function onGestionPagina()
    {
        if (getGet('pagina') != self::PAGE) return;
// Validamos
        $val = Validacion::getInstance();
// Validamos los elementos que hay en $_POST
        $toValidate = ($_POST);
        $rules = array(
            'usuario' => 'required|alphanum_simple',
            'clave' => 'required|alphanum_simple',
        );
        $usuario = getPost('usuario');
        $clave = getPost('clave');
        if (Login::searchUsuarioDB($usuario, $clave))
            $val->setExists(true);
        $val->addRules($rules);
        $val->run($toValidate);
        if (!is_null(getPost(self::PAGE))) {
            if ($val->isValid()) {
// Guardamos los datos en session
                $_SESSION[self::PAGE] = $val->getOks();
                $usuario = getPost('usuario');
                $clave = getPost('clave');
                $_SESSION['info'] = 'nologged';
                $datos = Login::searchUsuarioEncriptadoDB($usuario);
                if ($datos) {
                    // Verificamos si el hash de la clave ($datos[0]) coincide con la clave introducida por el usuario a través del formulario
                    if (password_verify($clave, $datos))
                        $_SESSION['info'] = 'logged';
                }
                    // Cambiamos el paso
                redirectTo('index.php?pagina=menu');
            }
        }
    }

    public function onCargarVista($path)
    {
        if (getGet('pagina') != self::PAGE) return;
        ob_start();
        include $path;
        $vista = ob_get_contents();
        ob_end_clean();
        echo loginParser::loadContent($vista);
    }
}