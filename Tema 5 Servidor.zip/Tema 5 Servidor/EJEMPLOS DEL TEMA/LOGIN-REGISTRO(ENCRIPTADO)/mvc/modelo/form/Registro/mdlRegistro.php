<?php
class mdlRegistro extends Singleton
{
    const PAGE = 'registro';
    public function onGestionPagina()
    {
        if (getGet('pagina') != self::PAGE) return;
// Para acceder a está página hay que pasar por login y por tanto $_SESSION['info'] tiene contenido
        if (is_null(Session::get('info'))) redirectTo('index.php');
// Validamos
        $val = Validacion::getInstance();
// Validamos los elementos que hay en $_POST
        $toValidate = ($_POST);
        $rules = array(
            'usuario' => 'required|alphanum_simple|duplicate',
            'clave' => 'required|alphanum_simple',
            'nombre' => 'required|alpha_space',
            'apellidos' => 'required|alpha_space',
            'email' => 'required|email'
        );
        $usuario = getPost('usuario');
// Verificamos si existe el usuario
        if (Login::duplicateLogin($usuario))
            $val->setExists(true);
        $val->addRules($rules);
        $val->run($toValidate);
        if (!is_null(getPost(self::PAGE))) {
            if ($val->isValid()) {
// Guardamos los datos en session
                $_SESSION[self::PAGE] = $val->getOks();
                $data = $_SESSION['registro'];
                // Generamos el hash de la clave
                $data['clave'] = encodePassword($data['clave']);
                $datos = Login::insertMedooDB($data);
                if ($datos) {
                    $_SESSION['info'] = 'registed';
                } else
                    $_SESSION['info'] = 'noRegisted';
// Cambiamos el paso
                redirectTo('index.php?pagina=menu');
            }
        }
    }
    public function onCargarVista($path)
    {
        if (getGet('pagina') != self::PAGE) return;
        ob_start();
        include $path;
        $vista = ob_get_contents();
        ob_end_clean();
        echo RegistroParser::loadContent($vista);
    }
}