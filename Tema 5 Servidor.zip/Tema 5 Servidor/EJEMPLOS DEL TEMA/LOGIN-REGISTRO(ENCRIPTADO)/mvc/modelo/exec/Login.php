<?php
class Login
{
    public static function searchUsuarioEncriptadoDB($usuario)
    {
        $database = medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $datos = $database->select('login', 'clave', [
            "usuario[=]" => $usuario
        ]);
        $database->closeConnection();
        if ($datos)
            return $datos[0];
        else
            return $datos;
    }
    public static function searchUsuarioDB($usuario, $clave)
    {
        $database = medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);

        //todo Comprueba en la base de datos que existen ese usuario con esa clave
        $datos = $database->count('login', [
            'AND' => [
                'usuario' => $usuario,
                'clave' => $clave
            ]
        ]) > 0;
        $database->closeConnection();
        return $datos;
    }
    static function duplicateLogin($campo)
    {
        $database = medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $datos = ($database->count('login', ['usuario' => $campo]) > 0) ? true : false;
        //ESTA MANERA SERIA CON SELECT
        //$datos = $database->select('socios', '*', ['dni' => $dni]);
        $database->closeConnection();
        return $datos;

    }
    public static function insertMedooDB($data)
    {
        $database = medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $datos = $database->insert('login', $data);
        $database->closeConnection();
        return $datos;
    }

}