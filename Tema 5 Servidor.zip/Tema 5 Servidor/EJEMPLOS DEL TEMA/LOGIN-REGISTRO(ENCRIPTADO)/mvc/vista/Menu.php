<html>
<head>
    <meta charset="UTF-8">
    <title>Listado de usuarios</title>
    <style>
        dl {
            padding-top: 50px;
        }
    </style>
</head>
<body>
<h1>Listado de usuarios</h1>
{{register}}
<br>
{{msg}}
<br><a href="index.php?pagina=login">Página principal</a>
</body>
</html>
