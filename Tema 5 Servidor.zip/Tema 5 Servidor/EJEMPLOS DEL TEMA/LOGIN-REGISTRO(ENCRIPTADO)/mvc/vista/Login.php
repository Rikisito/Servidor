<?php $val = Validacion::getInstance(); ?>
<html>
<head>
    <meta charset="UTF-8">
    <title>GESTION DE LA BASE DE DATOS DE USUARIOS</title>
    <style>
        form {
            padding-top: 50px;
        }
        .has-error { background: red; color: white; padding: 0.2em; }
        .has-warning { background: blue; color: white; padding: 0.2em; }
    </style>
</head>
<body>
<div>
    <form action="index.php?pagina=login" method="post">
        <h1>VALIDACION DE USUARIOS</h1>
        {{errores}}
        <div>
            <label class="{{class-usuario}}" for="usuario">Usuario</label>
            <input type="text" id="usuario" name="usuario"
                   value='<?php echo $val->restoreValue('usuario'); ?>' >
            <span>{{war-usuario}}</span>
        </div>
        <br>
        <div>
            <label class="{{class-clave}}" for="clave">Clave</label>
            <input type="text" id="clave" name="clave"
                   value='<?php echo $val->restoreValue('clave'); ?>' >
            <span>{{war-clave}}</span>
        </div>
        <br>
        <div>
            <button type="submit" name="login">Login</button>
        </div>
    </form>
</div>
</body>
</html>