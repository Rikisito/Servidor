<?php

class Usuario
{
    public static function searchIdDB($id)
    {
        $database = Medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $datos = $database->select('usuarios', '*', ["id[=]" => $id]);
        $database->closeConnection();
        return $datos;
    }
}