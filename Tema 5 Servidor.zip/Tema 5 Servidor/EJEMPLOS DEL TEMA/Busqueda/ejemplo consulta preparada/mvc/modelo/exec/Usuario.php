<?php

class Usuario
{
    public static function searchIdDB($id)
    {
        $database = Conexion::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $sql = "select * from usuarios where id = :id";
        $pdo = $database->getPdo();
        $query = $pdo->prepare($sql);
        $param = array(":id" => $id);
        $query->execute($param);
        $datos = $query ? $query->fetchAll() : false;
        $database->closeConnection();
        return $datos;
    }
}