<?php $val = Validacion::getInstance(); ?>
<html>
<head>
    <meta charset="UTF-8">
    <title>GESTION DE LA BASE DE DATOS DE USUARIOS</title>
    <style>
        form {
            padding-top: 50px;
        }
        .has-error { background: red; color: white; padding: 0.2em; }
        .has-warning { background: blue; color: white; padding: 0.2em; }
    </style>
</head>
<body>
<div>
    <form action="index.php?pagina=busqueda" method="post">
        <h1>GESTION DE LA BASE DE DATOS DE USUARIOS. BUSCAR</h1>
        {{errores}}
        <div>
            <label class=" {{class-id}}" for="id">Id</label>
            <input type="text" id="id" name="id"
                   value='<?php echo $val->restoreValue('id'); ?>' >
            <span>{{war-id}}</span>
        </div>
        <br>
        <div>
            <button type="submit" name="busqueda">Buscar </i></button>
        </div>
    </form>
</div>
</body>
</html>