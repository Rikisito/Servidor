<html>
    <head>
        <meta charset="UTF-8">
        <title>Listado de usuarios</title>
        <style>
            dl {
                padding-top: 50px;
            }
        </style>
    </head>
    <body>
        <h1>Modificación de usuarios</h1>
        {{mensaje}}
        <br>
    </body>
    <a href="index.php">Volver a Inicio</a>
</html>
