<?php

class Usuario
{
    public static function searchIdDB($id)
    {
        $database = Conexion::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $sql = "select * from usuarios where id = " . $id;
        $pdo = $database->getPdo();
        $query = $pdo->query($sql);
        $datos = $query ? $query->fetchAll() : false;
        $database->closeConnection();
        return $datos;
    }

    public static function modifyDB($nombre, $id)
    {
        $database = Conexion::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $sql = "update usuarios set nombre = '" . $nombre . "' where id = " . $id;
        $pdo = $database->getPdo();
        $datos = $pdo->exec($sql); // exec devuelve el número de registros eliminados
        $database->closeConnection();
        return $datos;
    }

    public static function searchPreparadaIdDB($id)
    {
        $database = Conexion::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $sql = "select * from usuarios where id = :id";
        $pdo = $database->getPdo();
        $query = $pdo->prepare($sql);
        $param = array(":id" => $id);
        $query->execute($param);
        $datos = $query ? $query->fetchAll() : false;
        $database->closeConnection();
        return $datos;
    }

    public static function modifyPreparadaDB($nombre, $id)
    {
        $database = Conexion::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $sql = "update usuarios set nombre = :nombre where id = :id";
        $pdo = $database->getPdo();
        $query = $pdo->prepare($sql);
        $param = array(":nombre" => $nombre, ":id" => $id);
        $query->execute($param);
        $datos = $query->rowCount() > 0 ? true : false;
        $database->closeConnection();
        return $datos;
    }


    public static function searchMedooIdDB($id)
    {
        $database = medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $datos = $database->select('usuarios', '*', ["id[=]" => $id]);
        $database->closeConnection();
        return $datos;
    }

    public static function modifyMedooDB($data, $id)
    {
        $database = medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $datos = $database->update('usuarios', $data, ['id' => $id]);
        $database->closeConnection();
        return $datos;
    }


}