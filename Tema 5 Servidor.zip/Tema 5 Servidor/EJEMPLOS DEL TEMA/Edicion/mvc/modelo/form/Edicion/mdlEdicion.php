<?php

class mdlEdicion extends Singleton
{
    const PAGE = 'edicion';

    public function onGestionPagina()
    {
        if (getGet('pagina') != self::PAGE) return;
        $search = $_SESSION['modificacion']['id'];
        if (is_null(getPost(self::PAGE))) { //verificamos si no se ha pulsado el botón edición
            $datos = Clientes::searchIdDB($search);
            if (count($datos) > 0) {
// Utilizamos la validación para rellenar los campos del formulario.
                $val = Validacion::getInstance();
// guardamos la fila devuelta en $toValidate
                $toValidate = $datos[0];
                $rules = array(
                    'nombre' => 'required|alpha_space'
                );
                $val->addRules($rules);
                $val->run($toValidate);
            } else
                redirectTo('index.php?pagina=mensaje');
        } else {

            // Validamos
            $val = Validacion::getInstance();
            $toValidate = $_POST;
            $rules = array(
                'nombre' => 'required|alpha_space'
            );
            $val->addRules($rules);
            $val->run($toValidate);
// Guardamos los datos en la sesión
            if ($val->isValid()) {
                $_SESSION[self::PAGE] = $val->getOks();
                $id = $_SESSION['modificacion']['id'];

                // Guardamos en el array $data los datos de $_SESSION['edicion'] q
                //ue sólo contiene el nombre pero el método Clientes::modifyDB espera un array
                $data = $_SESSION['edicion'];
                $datos = Clientes::modifyMedooDB($data, $id);

                /*
                $nombre = $_SESSION[self::PAGE]['nombre'];
                $datos = Clientes::modifyDB($nombre, $id);
                */
                /*
                $nombre = $_SESSION[self::PAGE]['nombre'];
                $datos = Clientes::modifyPreparadaDB($nombre, $id);
                */
                if ($datos)
                    $_SESSION['mod'] = true;
                else
                    $_SESSION['mod'] = false;
                redirectTo('index.php?pagina=mensaje');
            }
        }
    }

    public function onCargarVista($path)
    {
        if (getGet('pagina') != self::PAGE) return;
        ob_start();
        include $path;
        $vista = ob_get_contents();
        ob_end_clean();
        echo EdicionParser::loadContent($vista);
    }
}