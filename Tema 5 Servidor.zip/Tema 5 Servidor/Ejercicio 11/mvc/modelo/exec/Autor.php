<?php

class Autor
{

    public static function searchIdDB($id)
    {
        $database = Medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $datos = $database->select("autores", "*", ["id[=]" => $id]);
        $database->closeConnection();
        return $datos;
    }

    public static function searchAllDB()
    {
        $database = Medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $datos = $database->select("autores", "*");
        $database->closeConnection();
        return $datos;
    }

    public static function modifyDB($id, $nombre, $apellidos)
    {
        $database = Medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $datos = $database->update("autores", ["nombre" => $nombre, "apellidos" => $apellidos], ["id[=]" => $id]);
        $database->closeConnection();
        return $datos;
    }

    public static function insertDB($nombre, $apelldios)
    {
        $database = Medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $datos = $database->insert("autores", ["nombre" => $nombre, "apellidos" => $apelldios]);
        $database->closeConnection();
        return $datos;
    }

    public static function removeDB($id)
    {
        $database = medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $datos = $database->delete('autores', ["id[=]" => $id]);
        $datos = $datos->rowCount() > 0 ? true : false; //medoo devuelve un objeto statement
        $database->closeConnection();
        return $datos;
    }

}