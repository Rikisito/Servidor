<?php

/**
 * Created by PhpStorm.
 * User: Daw2
 * Date: 16/01/2019
 * Time: 11:28
 */
class Telefono
{
    static private $_sql;
    static private $_query;

    public static function insertDB($data)
    {
        $database = medoo::getInstance();
// ojo!!!: no abrimos conexión
        $sql = "insert into telefonos (idTrab, telefono) values (:idTrab, :telefono)";
        $param = array(":idTrab" => $data['idtrab'], ":telefono" => $data['telefono']);
// Sólo se prepara la consulta con el primer teléfono
        if (self::$_sql != $sql) {
            self::$_query = $database->pdo->prepare($sql);
            self::$_sql = $sql;
        }
        $datos = self::$_query->execute($param);
// ojo!!!: no cerramos conexión
        return $datos;
    }
}