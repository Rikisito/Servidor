<?php

/**
 * Created by PhpStorm.
 * User: Daw2
 * Date: 16/01/2019
 * Time: 11:27
 */
class Trabajador
{

    public static function duplicateDNI($dni) {
        $database = Medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $datos = ($database->count('trabajadores', ['dni' => $dni]) > 0) ? true : false;
        $database->closeConnection();
        return $datos;
    }

    public static function insertDB($data)
    {
        $database = medoo::getInstance();
// ojo!!!: no abrimos conexión
        $datos = $database->insert('trabajadores', $data);
// ojo!!!: no cerramos conexión
        return $datos;
    }
}