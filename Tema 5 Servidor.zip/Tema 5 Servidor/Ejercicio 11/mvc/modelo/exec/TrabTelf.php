<?php

/**
 * Created by PhpStorm.
 * User: Daw2
 * Date: 16/01/2019
 * Time: 11:27
 */
class TrabTelf
{
    public static function insertDB($data)
    {
        $database = medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
// Comienza la transaccion
        $database->pdo->beginTransaction();
        $trabajador = array();
        $telefonos = array();
        foreach ($data as $field => $value) {
            if (!$value) continue;// no trata el botón de envío de formulario
            if ($field == 'telefono1' || $field == 'telefono2')
                $telefonos[] = $value;
            else
                $trabajador[$field] = $value;
        }
        $datos = Trabajador::insertDB($trabajador);
        if ($datos) {
// almacenamos el último id insertado
            $id = $database->pdo->lastInsertId();
            foreach ($telefonos as $telf) {
                $telefono['idtrab'] = $id;
                $telefono['telefono'] = $telf;
                $datos = Telefono::insertDB($telefono);
            }
        }
        if ($datos)
            $database->pdo->commit();
        else
            $database->pdo->rollBack();
        $database->closeConnection();
        return $datos;
    }
}