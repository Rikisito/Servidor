<?php

/**
 * Created by PhpStorm.
 * User: Daw2
 * Date: 15/01/2018
 * Time: 9:43
 */
class mdlMenu extends Singleton
{
    const PAGE = 'menu';

    public function onGestionPagina()
    {
        if (self::PAGE != getGet('pagina', 'menu')) return;
        if ($_SESSION['info'] != 'logged') {
            redirectTo('index.php');
        }
    }

    public function onCargarVista($path)
    {
        if (self::PAGE != getGet('pagina', 'menu')) return;
        ob_start();
        include $path;
        $vista = ob_get_contents();
        ob_end_clean();
        echo $vista;
    }
}
