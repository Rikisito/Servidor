<?php
/**
 * <!--
 *   Copyright (C) Daw2 2018
 *
 *
 *
 *   This program is free software: you can redistribute it and/or modify
 *
 *   it under the terms of the GNU General Public License as published by
 *
 *   the Free Software Foundation, either version 3 of the License, or
 *
 *   (at your option) any later version.
 *
 *
 *
 *   This program is distributed in the hope that it will be useful,
 *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *
 *   GNU General Public License for more details.
 *
 *
 *
 *   You should have received a copy of the GNU General Public License
 *
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>
 *   -->
 */

class mdlLogin extends Singleton
{
    const PAGE = 'login';

    public function onGestionPagina()
    {
        if (getGet('pagina') != self::PAGE) return;
// Validamos
        $val = Validacion::getInstance();
// Validamos los elementos que hay en $_POST
        $toValidate = ($_POST);
        $rules = array(
            'usuario' => 'required|alphanum_simple',
            'clave' => 'required|alphanum_simple',
        );
        $usuario = getPost('usuario');
        $clave = getPost('clave');
        if (Login::searchUsuarioDB($usuario, $clave))
            $val->setExists(true);
        $val->addRules($rules);
        $val->run($toValidate);
        if (!is_null(getPost(self::PAGE))) {
            if ($val->isValid()) {
// Guardamos los datos en session
                $_SESSION[self::PAGE] = $val->getOks();
                $usuario = getPost('usuario');
                $clave = getPost('clave');
                $_SESSION['info'] = 'nologged';
                $datos = Login::searchUsuarioEncriptadoDB($usuario);
                if ($datos) {
                    // Verificamos si el hash de la clave ($datos[0]) coincide con la clave introducida por el usuario a través del formulario
                    if (password_verify($clave, $datos)) {
                        $_SESSION['info'] = 'logged';
                        redirectTo('index.php?pagina=menu');
                    }
                }
                // Cambiamos el paso
                redirectTo('index.php?pagina=mensaje');
            }
        }
    }

    public function onCargarVista($path)
    {
        if (getGet('pagina') != self::PAGE) return;
        ob_start();
        include $path;
        $vista = ob_get_contents();
        ob_end_clean();
        echo loginParser::loadContent($vista);
    }
}