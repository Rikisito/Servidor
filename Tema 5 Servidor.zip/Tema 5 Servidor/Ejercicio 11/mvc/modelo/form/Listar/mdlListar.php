<?php

class mdlListar extends Singleton
{
    const PAGE = 'listar';

    public function onGestionPagina()
    {
        if (getGet('pagina') != self::PAGE) return;
        if ($_SESSION['info']!='logged') {
            redirectTo('index.php');
        }
// Accedemos a la base de datos y guardamos los datos en session
// Inicializamos $_SESSION['listar'] para que la página del listado se viualice sólo si se pasa antes por listar
        $_SESSION[self::PAGE] = true;
        $_SESSION['datos'] = Autor::searchAllDB();
        redirectTo('index.php?pagina=listado');
    }
}