<?php

class mdlEdicion extends Singleton {
	const PAGE = 'edicion';

	public function onGestionPagina() {
		if (getGet('pagina') != self::PAGE) return;
        if ($_SESSION['info'] != 'logged') {
            redirectTo('index.php');
        }
        if (!isset($_SESSION['modificacion'])){
        	redirectTo('index.php?pagina=menu');
		}
		$search = $_SESSION['modificacion']['id'];
		if (is_null(getPost(self::PAGE))) { //verificamos si no se ha pulsado el botón edición
			$datos = Autor::searchIdDB($search);
			if (count($datos) > 0) {
// Utilizamos la validación para rellenar los campos del formulario.
				$val = Validacion::getInstance();
				$toValidate = $datos[0];
				$rules = array(
					'nombre' => 'required|alpha_space',
					'apellidos' => 'required|alpha_space'
				);
				$val->addRules($rules);
				$val->run($toValidate);
			} else
				redirectTo('index.php?pagina=mensaje');
		} else {
// Validamos
			$val = Validacion::getInstance();
			$toValidate = $_POST;
			$rules = array(
				'nombre' => 'required|alpha_space',
				'apellidos' => 'required|alpha_space'
			);
			$val->addRules($rules);
			$val->run($toValidate);
// Guardamos los datos en la sesión
			if ($val->isValid()) {
				$_SESSION[self::PAGE] = $val->getOks();
				$datos = Autor::modifyDB($_SESSION['modificacion']['id'], $_SESSION[self::PAGE]['nombre'], $_SESSION[self::PAGE]['apellidos']);
				if ($datos)
					$_SESSION['mod'] = true;
				else
					$_SESSION['mod'] = false;
				redirectTo('index.php?pagina=mensaje');
			}
		}
	}

	public function onCargarVista($path) {
		if (getGet('pagina') != self::PAGE) return;
		ob_start();
		include $path;
		$vista = ob_get_contents();
		ob_end_clean();
		echo EdicionParser::loadContent($vista);
	}
}

?>
