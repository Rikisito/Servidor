<?php
class mdlListado extends Singleton {
	const PAGE = 'listado';
	public function onGestionPagina() {
		if (getGet('pagina') != self::PAGE) return;
        if ($_SESSION['info'] != 'logged') {
            redirectTo('index.php');
        }
	}
	public function onCargarVista($path) {
		if (getGet('pagina') != self::PAGE) return;
		ob_start();
		include $path;
		$vista = ob_get_contents();
		ob_end_clean();
		echo ListadoParser::loadContent($vista);
	}
}