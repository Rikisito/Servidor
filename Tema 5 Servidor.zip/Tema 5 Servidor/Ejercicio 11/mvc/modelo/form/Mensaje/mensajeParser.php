<?php

class MensajeParser
{
    public static function loadContent($vista)
    {
        $vista = self::_pasoSiguiente($vista);
        return $vista;
    }

    private static function _pasoSiguiente($vista)
    {
        foreach (getTagsVista($vista) as $tag) {
// sustituimos en el formulario los tags por el contenido de los elementos del formulario
            $str = '';
            switch ($tag) {
                case 'mensaje':
                    if (isset ($_SESSION['ins'])) {
                        if (Session::get('ins'))
                            $str = '<p> <b>Autor guardado</b></p><br><br><a href="index.php?pagina=menu">Volver al menu</a><br><br>';
                        else
                            $str = '<p> <b>No se ha podido salvar los datos</b></p>';
                        Session::get('ins');
                    } elseif (isset ($_SESSION['elim'])) {
                        if (Session::get('elim'))
                            $str = '<p> <b>Autor eliminado</b></p><br><br><a href="index.php?pagina=menu">Volver al menu</a><br><br>';
                        else
                            $str = '<p> <b>El autor no existe...</b></p>';
                        Session::get('elim');
                    } elseif (isset ($_SESSION['edicion'])) {
                        if ($_SESSION['mod']) {
                            $str = '<p> <b>Usuario modificado</b></p><br><br><a href="index.php?pagina=menu">Volver al menu</a><br><br>';
                        } else {
                            $str = '<p> <b>No se han podido modificar los datos...</b></p>';
                        }
                        Session::get('edicion');
                    } elseif (Session::get('info') == 'registed') {
                        $str = 'Usuario guardado';
                        Session::del('info'); // No permitimos ir al registro desde aqui
                    } elseif (Session::get('info') == 'noRegisted') {
                        $str = 'El usuario no se ha podido guardar';
                        Session::del('info'); // No permitimos ir al registro desde aqui
                    } elseif (Session::get('info') == 'nologged') {
                        $str = 'El usuario/password no existe<br><br>';
                        $str .= "<a href=\"index.php?pagina=registro\">Registrarse</a>";
                    } else {
                        $str = '<p> <b>El autor no existe</b></p>';
                    }
                    Session::del('elim');
                    break;
            }
            $vista = str_replace('{{' . $tag . '}}', $str, $vista);
        }
        return $vista;
    }
}

?>
