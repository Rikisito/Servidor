<?php $val = Validacion::getInstance(); ?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>GESTION DE LA BASE DE DATOS DE USUARIOS</title>
        <style>
            form {
                padding-top: 50px;
            }
            .has-error { background: red; color: white; padding: 0.2em; }
            .has-warning { background: blue; color: white; padding: 0.2em; }
        </style>
    </head>
    <body>
        <div>
            <form action="index.php?pagina=registro" method="post">
                <h1>GESTION DE LA BASE DE DATOS DE USUARIOS. añadir</h1>
                {{errores}}
                <div>
                    <label class=" {{class-usuario}}" for="usuario">usuario</label>
                    <input type="text" id="usuario" name="usuario"
                           value='<?php echo $val->restoreValue('Clientes'); ?>' >
                    <span>{{war-usuario}}</span>
                </div>
                <br>
                <div>
                    <label class=" {{class-clave}}" for="clave">password</label>
                    <input type="text" id="clave" name="clave"
                           value='<?php echo $val->restoreValue('clave'); ?>' >
                    <span>{{war-clave}}</span>
                </div>
                <br>
                <div>
                    <label class=" {{class-nombre}}" for="nombre">nombre</label>
                    <input type="text" id="nombre" name="nombre"
                           value='<?php echo $val->restoreValue('nombre'); ?>' >
                    <span>{{war-nombre}}</span>
                </div>
                <br>
                <div>
                    <label class=" {{class-apellidos}}" for="apellidos">apellidos</label>
                    <input type="text" id="apellidos" name="apellidos"
                           value='<?php echo $val->restoreValue('apellidos'); ?>' >
                    <span>{{war-apellidos}}</span>
                </div>
                <br>
                <div>
                    <label class=" {{class-email}}" for="email">email</label>
                    <input type="text" id="email" name="email"
                           value='<?php echo $val->restoreValue('email'); ?>' >
                    <span>{{war-email}}</span>
                </div>
                <br>
                <div>
                    <button type="submit" name="registro">Registrar</i></button>
                </div>
            </form>
        </div>
    </body>
</html>