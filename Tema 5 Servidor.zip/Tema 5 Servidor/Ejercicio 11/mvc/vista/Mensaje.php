<html>
    <head>
        <meta charset="UTF-8">
        <title>Listado de usuarios</title>
        <style>
            dl {
                padding-top: 50px;
            }
        </style>
    </head>
    <body>
        <h1>Listado de usuarios</h1>
        {{mensaje}}
        <br>
    </body>
    <a href="index.php?pagina=login">Volver a Inicio</a>
</html>
