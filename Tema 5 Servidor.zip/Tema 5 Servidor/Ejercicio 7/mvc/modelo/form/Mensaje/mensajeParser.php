<?php

class MensajeParser
{
    public static function loadContent($vista)
    {
        $vista = self::_pasoSiguiente($vista);
        return $vista;
    }

    private static function _pasoSiguiente($vista)
    {
        foreach (getTagsVista($vista) as $tag) {
// sustituimos en el formulario los tags por el contenido de los elementos del formulario
            $str = '';
            switch ($tag) {
                case 'mensaje':
// Si existe $_SESSION['edicion'] es que el ID introducido a través del formulario existe
                    if (isset($_SESSION['edicion']) || isset($_SESSION['insercion']) || isset($_SESSION['eliminacion'])) {
                        if (isset($_SESSION['mod'])&& $_SESSION['mod'] == true) {
                            $str = '<p> <b>Autor modificado</b></p>';
                        } else if (isset($_SESSION['ins']) && $_SESSION['ins'] == true) {
                            $str = '<p> <b>Autor Insertado</b></p>';
                        } else if (isset($_SESSION['elim']) && $_SESSION['elim'] == true) {
                            $str = '<p> <b>Autor eliminado</b></p>';
                        } else {
                            $str = '<p> <b>No se han podido modificar los datos...</b></p>';
                        }
                    } else
                        $str = '<p> <b>El Autor no existe</b></p>';
                    break;
            }
            $vista = str_replace('{{' . $tag . '}}', $str, $vista);
        }
        return $vista;
    }
}
?>
