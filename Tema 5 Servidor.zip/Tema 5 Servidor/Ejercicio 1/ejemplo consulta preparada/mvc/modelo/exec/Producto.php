<?php

class Producto
{
    public static function searchNombreDB($id)
    {
        $database = Conexion::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $sql = "select * from productos where nombre = :nombre";
        $pdo = $database->getPdo();
        $query = $pdo->prepare($sql);
        $param = array(":nombre" => $id);
        $query->execute($param);
        $datos = $query ? $query->fetchAll() : false;
        $database->closeConnection();
        return $datos;
    }
}