<?php

class ListadoParser
{
    public static function loadContent($vista)
    {
        $vista = self::_pasoSiguiente($vista);
        return $vista;
    }

    private static function _pasoSiguiente($vista)
    {
        foreach (getTagsVista($vista) as $tag) {
// sustituimos en el formulario los tags por el contenido de los elementos del formulario
            $str = '';
            switch ($tag) {
                case 'listado':
                    $datos = $_SESSION['datos'];
                    if ($datos) {
                        $str = "<table border='1'>
<thead>
<tr>
<th>CODIGO</th>
<th>Nombre</th>
<th>PRECIO</th>
</tr>
</thead>
";
                        foreach ($datos as $producto) {
                            $str .= "
<tr>
<td>" . $producto['codigo'] . "</td>
<td><strong>" . $producto['nombre'] . "</strong></td>
<td><strong>" . $producto['precio'] . "</strong></td>
</tr>
";
                        }
                        $str .= "</table>";
                    } else
                        $str = '<p> <b>No se han encontrado resultados...</b></p>';
                    break;
            }
            $vista = str_replace('{{' . $tag . '}}', $str, $vista);
        }
        return $vista;
    }
}