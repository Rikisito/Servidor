<?php

class Producto
{
    public static function searchNombreDB($id)
    {
        $database = Medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $datos = $database->select('productos', '*', ["nombre[=]" => $id]);
        $database->closeConnection();
        return $datos;
    }
}