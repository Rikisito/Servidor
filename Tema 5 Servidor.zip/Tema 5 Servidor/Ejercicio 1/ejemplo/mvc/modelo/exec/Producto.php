<?php
class Producto {
    public static function searchNombreDB($nombre) {
        $database = Conexion::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $sql = "select * from productos where nombre =  '$nombre'";
        $pdo=$database->getPdo();
        $query = $pdo->query($sql);//query para los select, exec para insert, delete, update...
        $datos = $query ? $query->fetchAll() : false;
        $database->closeConnection();
        return $datos;
    }
}