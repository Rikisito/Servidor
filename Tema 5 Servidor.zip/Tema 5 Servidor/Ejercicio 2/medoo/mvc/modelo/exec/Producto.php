<?php

class Producto
{
    public static function searchCodigoDB()
    {
        $database = medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);

        $columnas = ["codigo", "nombre"];

        $precio = $codigo = $_SESSION['busqueda']['precio'];
        $cantidad = $codigo = $_SESSION['busqueda']['cantidad'];

        /*
        if (isset($_SESSION['busqueda']['precio']))
            $columnas[]='precio';
        if (isset($_SESSION['busqueda']['cantidad']))
            $columnas[]='cantidad';
        */
        $precio ? $columnas[] = "precio" : $precio;
        $cantidad ? $columnas[] = "cantidad" : $cantidad;

        $datos = $database->select('productos', $columnas, ["codigo[=]" => $codigo = $_SESSION['busqueda']['codigo']]);
        $database->closeConnection();
        return $datos;
    }

    //Cambiar en mdl y la vista, los check box como array opciones[]
    public static function searchCodigoDinamicDB($codigo)
    {
        $database = medoo::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $campos = ['codigo', 'nombre'];
        if (isset($_SESSION['busqueda']['opciones'])) {
            foreach ($_SESSION['busqueda']['opciones'] as $value) {
                Array_push($campos, $value);
            }
        }
        $datos = $database->select('productos', $campos, ["codigo[~]" => $codigo]);
        return $datos;
    }
}