<?php $val = Validacion::getInstance(); ?>
<html>
<head>
    <meta charset="UTF-8">
    <title>GESTION DE LA BASE DE DATOS DE USUARIOS</title>
    <style>
        form {
            padding-top: 50px;
        }
        .has-error { background: red; color: white; padding: 0.2em; }
        .has-warning { background: blue; color: white; padding: 0.2em; }
    </style>
</head>
<body>
<div>
    <form action="index.php?pagina=busqueda" method="post">
        <h1>GESTION DE LA BASE DE DATOS DE USUARIOS. BUSCAR</h1>
        {{errores}}
        <div>
            <label class=" {{class-codigo}}" for="codigo">Codigo</label>
            <input type="text" id="codigo" name="codigo"
                   value='<?php echo $val->restoreValue('codigo'); ?>' >
            <span>{{war-id}}</span>
        </div>
        Mostrar precio <input type="checkbox" id="precio" name="precio" value="Mostrar precio" <?php echo $val->restoreCheckboxes('precio', 'Mostrar precio'); ?>><br>
        Mostrar cantidad <input type="checkbox" id="cantidad" name="cantidad" value="Mostrar cantidad" <?php echo $val->restoreCheckboxes('cantidad', 'Mostrar cantidad'); ?>>
        <br>
        <div>
            <button type="submit" name="busqueda">Buscar </i></button>
        </div>
    </form>
</div>
</body>
</html>