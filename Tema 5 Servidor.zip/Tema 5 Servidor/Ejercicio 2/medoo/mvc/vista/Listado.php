<html>
<head>
    <meta charset="UTF-8">
    <title>Listado de usuarios</title>
    <style>
        dl {
            padding-top: 50px;
        }
    </style>
</head>
<body>
<h1>Listado de usuarios</h1>
{{listado}}
<br>
<a href="index.php">Volver a Inicio</a>
</body>
</html>