<?php

class Producto
{
    public static function searchCodigoDB()
    {
        $database = Conexion::getInstance();
        $database->openConnection(MYSQL_CONFIG);
        $sql = "select codigo, nombre";
        if (isset ($_SESSION['busqueda']['precio']))
            $sql .= ',precio ';
        if (isset ($_SESSION['busqueda']['cantidad']))
            $sql .= ',cantidad ';
        $sql .= ' from productos where codigo = :codigo';
        $pdo = $database->getPdo();
        $query = $pdo->prepare($sql);
        $codigo = $_SESSION['busqueda']['codigo'];
        $param = array(":codigo" => $codigo);
        $query->execute($param);
        $datos = $query ? $query->fetchAll(PDO::FETCH_ASSOC) : false;
        $database->closeConnection();
        return $datos;
    }
}