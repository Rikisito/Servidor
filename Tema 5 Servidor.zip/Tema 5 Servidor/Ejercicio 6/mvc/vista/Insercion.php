<?php $val = Validacion::getInstance(); ?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>GESTION DE LA BASE DE DATOS DE USUARIOS</title>
        <style>
            form {
                padding-top: 50px;
            }
            .has-error { background: red; color: white; padding: 0.2em; }
            .has-warning { background: blue; color: white; padding: 0.2em; }
        </style>
    </head>
    <body>
        <div>
            <form action="index.php?pagina=insercion" method="post">
                <h1>GESTION DE LA BASE DE DATOS DE USUARIOS. INSERCIÓN DE USUARIOS</h1>
                {{errores}}
                <div>
                    <label class="{{class-nombre}}" for="nombre">Nombre</label>
                    <input type="text" id="nombre" name="nombre"
                           value='<?php echo $val->restoreValue('nombre'); ?>' >
                    <span>{{war-nombre}}</span>
                </div>
                <br>
                <div>
                    <label class="{{class-dni}}" for="dni">DNI</label>
                    <input type="text" id="dni" name="dni"
                           value='<?php echo $val->restoreValue('dni'); ?>' >
                    <span>{{war-dni}}</span>
                </div>
                <br>
                <div>
                    <label class="{{class-salario}}" for="salario">Salario</label>
                    <input type="text" id="salario" name="salario"
                           value='<?php echo $val->restoreValue('salario'); ?>' >
                    <span>{{war-salario}}</span>
                </div>
                <br>
                <div>
                    <label class="{{class-telefono1}}" for="telefono1">Telefono 1º</label>
                    <input type="text" id="telefono1" name="telefono1"
                           value='<?php echo $val->restoreValue('telefono1'); ?>' >
                    <span>{{war-telefono1}}</span>
                </div>
                <br>
                <div>
                    <label class="{{class-telefono2}}" for="telefono2">Telefono 2º</label>
                    <input type="text" id="telefono2" name="telefono2"
                           value='<?php echo $val->restoreValue('telefono2'); ?>' >
                    <span>{{war-telefono2}}</span>
                </div>
                <br>
                <div>
                    <button type="submit" name="insercion">Insertar</button>
                </div>
            </form>
        </div>
    </body>
</html>