<?php
class mdlInsercion extends Singleton {
    const PAGE = 'insercion';
    public function onGestionPagina() {
        if (getGet('pagina') != self::PAGE) return;
// Validamos
        $val = Validacion::getInstance();
// Validamos los elementos que hay en $_POST
        $toValidate = ($_POST);
        $rules = array(
            'nombre' => 'required|alpha_space',
            'dni' => 'required|dni|duplicate',
            'salario' => 'required|numeric',
            'telefono1' => 'required|integer',
            'telefono2' => 'repeated|integer'
        );
        $dni = getPost('dni');
// Verificamos si existe el DNI
        if (Trabajador::duplicateDNI($dni))
            $val->setExists(true);
        $telf1 = getPost('telefono1');
        $telf2 = getPost('telefono2');

        if ($telf1 == $telf2)
            $val->setTelfRepeat(true);

        $val->addRules($rules);
        $val->run($toValidate);
        if (!is_null(getPost(self::PAGE))) {
            if ($val->isValid()) {
// Guardamos los datos en session
                $_SESSION[self::PAGE] = $val->getOks();
// Al utilizar medoo, el argumento $data que se pasa a Socio::insertDB debe ser un array
                $data = $_SESSION['insercion'];
                $datos = TrabTelf::insertDB($data);
                if ($datos)
                    $_SESSION['ins'] = true;
                else
                    $_SESSION['ins'] = false;
// Cambiamos el paso
                redirectTo('index.php?pagina=mensaje');
            }
        }
    }
    public function onCargarVista($path) {
        if (getGet('pagina') != self::PAGE) return;
        ob_start();
        include $path;
        $vista = ob_get_contents();
        ob_end_clean();
        echo InsercionParser::loadContent($vista);
    }
}